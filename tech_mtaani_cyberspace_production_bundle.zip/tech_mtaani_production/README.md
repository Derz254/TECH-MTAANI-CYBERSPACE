# Tech Mtaani Cyberspace — frontend + request API

This package contains the existing website and an Express/PostgreSQL implementation for `POST /api/requests`.

## What is included
- Fixed initial price-list empty-state behavior and resilient text matching; original public price list retained.
- Request API stores request metadata in PostgreSQL and accepts one optional PDF/JPEG/PNG attachment up to 5 MB.
- Attachment content is checked by file signature, renamed to a random UUID, stored outside the public web directory with restrictive file permissions, and never exposed by a public download route.
- Helmet security headers, API rate limiting, input limits, parameterised SQL, request validation, and `/api/health`.
- Testimonial section contains no fabricated reviews; it invites genuine feedback.
- Privacy notice contains customer-facing language without developer footnotes.
- Map uses a general-area Likoni coordinate pin (-4.0850, 39.3060). This is not a verified exact storefront coordinate.

## Run locally
Requirements: Node.js 20+ and PostgreSQL.

1. Create a database and user in PostgreSQL.
2. Run `psql "$DATABASE_URL" -f schema.sql`.
3. Copy `.env.example` to `.env` and set `DATABASE_URL`, `PGSSLMODE`, and `UPLOAD_DIR` for your environment.
4. Run `npm install`.
5. Run `npm start`.
6. Visit `http://localhost:3000` and test `/api/health`.

The frontend is served from `public/`, and same-origin requests go to `/api/requests`. Successful submissions return HTTP 201 with `{ "requestId": "..." }`; the frontend then offers WhatsApp follow-up.

## Production deployment requirements
This code is not a live deployment by itself. To put it into production:
- Deploy the app to a host with HTTPS and persistent private storage.
- Use a managed PostgreSQL database with TLS, backups, least-privilege credentials, and monitoring.
- Set `PGSSLMODE=require` when required by your database provider; configure the provider's certificate trust as needed.
- Mount `UPLOAD_DIR` on a private persistent volume, not a public/static directory. Restrict host and staff access, encrypt storage and backups, and test restoration.
- Configure the hosting platform's trusted proxy setting correctly, then review rate limits for expected traffic.
- Add authenticated staff access and audit logs before allowing staff to view request records or attachments. No public attachment download endpoint is included.
- Define and implement a retention schedule, deletion job, incident response process, and a privacy notice reviewed against the actual operating practices and applicable Kenyan law.
- Add monitoring/alerts and test malformed uploads, size limits, concurrent submissions, DB outage, backup recovery and deletion.
- Do not expose database credentials in frontend code or commit `.env`.

## Important
The backend can store customer requests only after you deploy it and configure a real database. I cannot provision hosting, connect a live database, or deploy to your domain from this workspace because no hosting/database credentials or deployment access were supplied. No SMS OTP or M-Pesa STK Push is included in this build.
