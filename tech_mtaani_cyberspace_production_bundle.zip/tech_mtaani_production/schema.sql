CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS service_requests (
  id UUID PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  customer_phone VARCHAR(24) NOT NULL,
  service VARCHAR(120) NOT NULL,
  details TEXT NOT NULL,
  consent_at TIMESTAMPTZ NOT NULL,
  attachment_storage_name VARCHAR(80),
  attachment_original_name VARCHAR(180),
  attachment_mime_type VARCHAR(80),
  attachment_size_bytes INTEGER,
  status VARCHAR(24) NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_progress', 'completed', 'cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  CHECK (
    (attachment_storage_name IS NULL AND attachment_original_name IS NULL AND attachment_mime_type IS NULL AND attachment_size_bytes IS NULL)
    OR
    (attachment_storage_name IS NOT NULL AND attachment_original_name IS NOT NULL AND attachment_mime_type IS NOT NULL AND attachment_size_bytes BETWEEN 1 AND 5242880)
  )
);

CREATE INDEX IF NOT EXISTS service_requests_created_at_idx ON service_requests (created_at DESC);
CREATE INDEX IF NOT EXISTS service_requests_status_idx ON service_requests (status, created_at DESC);
