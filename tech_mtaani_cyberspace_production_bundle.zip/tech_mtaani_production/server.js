import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import pg from 'pg';
import { randomUUID } from 'node:crypto';
import { mkdir, writeFile, unlink } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fileTypeFromBuffer } from 'file-type';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATABASE_URL = process.env.DATABASE_URL;
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, 'private_uploads'));
if (!DATABASE_URL) throw new Error('DATABASE_URL must be configured.');
await mkdir(UPLOAD_DIR, { recursive: true, mode: 0o700 });

const pool = new pg.Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: true } : undefined,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

app.disable('x-powered-by');
app.set('trust proxy', Number(process.env.TRUST_PROXY || 0));
app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-site' } }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: 'draft-7', legacyHeaders: false }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 8, fieldSize: 8000 },
  fileFilter(_req, file, cb) {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const allowedExt = ['.pdf', '.jpg', '.jpeg', '.png'];
    if (!allowedExt.includes(ext)) return cb(new Error('Only PDF, JPEG and PNG files are accepted.'));
    cb(null, true);
  }
});

const textField = (v, max) => typeof v === 'string' ? v.trim().slice(0, max) : '';
const phoneRegex = /^(?:\+?254|0)?[17]\d{8}$/;
const SERVICE_OPTIONS = new Set([
  'KRA services', 'NSSF services', 'SHA services', 'eCitizen and online applications',
  'Typing, CV and document preparation', 'Printing, photocopying, scanning or lamination',
  'Wi-Fi and internet services', 'Computer training', 'Graphic design and branding',
  'Social media management', 'Bulk SMS (SMSLeopard) help', 'Other enquiry'
]);

app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch {
    res.status(503).json({ status: 'unavailable' });
  }
});

app.post('/api/requests', upload.single('supportingFile'), async (req, res, next) => {
  let savedPath;
  try {
    const customerName = textField(req.body.customerName, 120);
    const customerPhone = textField(req.body.customerPhone, 24).replace(/[\s()-]/g, '');
    const service = textField(req.body.service, 120);
    const details = textField(req.body.details, 4000);
    const consent = ['on', 'true', '1'].includes(String(req.body.consent || '').toLowerCase());

    if (!customerName || !customerPhone || !service || !details || !consent) {
      return res.status(400).json({ error: 'Please complete all required fields and confirm the privacy notice.' });
    }
    if (!phoneRegex.test(customerPhone)) {
      return res.status(400).json({ error: 'Enter a valid Kenyan phone number.' });
    }
    if (!SERVICE_OPTIONS.has(service)) {
      return res.status(400).json({ error: 'Select a valid service category.' });
    }

    let attachment = null;
    if (req.file) {
      const detected = await fileTypeFromBuffer(req.file.buffer);
      const allowedMime = new Set(['application/pdf', 'image/jpeg', 'image/png']);
      if (!detected || !allowedMime.has(detected.mime)) {
        return res.status(400).json({ error: 'The attachment content must be a valid PDF, JPEG or PNG.' });
      }
      const extensionByMime = { 'application/pdf': '.pdf', 'image/jpeg': '.jpg', 'image/png': '.png' };
      const storageName = `${randomUUID()}${extensionByMime[detected.mime]}`;
      savedPath = path.join(UPLOAD_DIR, storageName);
      await writeFile(savedPath, req.file.buffer, { flag: 'wx', mode: 0o600 });
      attachment = {
        storageName,
        originalName: path.basename(req.file.originalname).slice(0, 180),
        mimeType: detected.mime,
        sizeBytes: req.file.size
      };
    }

    const requestId = randomUUID();
    try {
      await pool.query(
        `INSERT INTO service_requests
         (id, customer_name, customer_phone, service, details, consent_at, attachment_storage_name, attachment_original_name, attachment_mime_type, attachment_size_bytes)
         VALUES ($1,$2,$3,$4,$5,NOW(),$6,$7,$8,$9)`,
        [requestId, customerName, customerPhone, service, details,
          attachment?.storageName ?? null, attachment?.originalName ?? null,
          attachment?.mimeType ?? null, attachment?.sizeBytes ?? null]
      );
    } catch (dbError) {
      if (savedPath) await unlink(savedPath).catch(() => {});
      savedPath = null;
      throw dbError;
    }
    res.status(201).json({ requestId });
  } catch (error) {
    next(error);
  }
});

// No public route serves private uploads. Add authenticated staff access before enabling downloads.
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], index: 'index.html' }));

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    const message = err.code === 'LIMIT_FILE_SIZE' ? 'Attachment must be 5 MB or smaller.' : 'Invalid upload. Use one PDF, JPEG or PNG file.';
    return res.status(400).json({ error: message });
  }
  if (err.message?.includes('Only PDF, JPEG and PNG')) return res.status(400).json({ error: err.message });
  console.error('Request API error:', err.message);
  res.status(500).json({ error: 'We could not process your request right now. Please try again later.' });
});

const server = app.listen(PORT, () => console.log(`Tech Mtaani server listening on port ${PORT}`));
const shutdown = async () => { server.close(); await pool.end(); process.exit(0); };
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
